The Book's Data - Statistics by Us for You
==========================================

Everything the SPSS, Julia and Python code tabs need. You do not need
git, GitHub, or an account anywhere to use this.

STEP 1. Unzip this file somewhere you will find again - the Desktop is
        fine. You get a folder called GradStats-data, holding a folder
        called data and one loader per language.

STEP 2 (SPSS). Open load_data.sps in SPSS, or in PSPP if you have no
        SPSS licence. Near the top is a line reading:

            * CD 'C:/path/to/GradStats-data'.

        Delete the asterisk and the space after it, and put the real
        location of the unzipped folder between the quotes:

            CD 'C:/Users/jeff/Desktop/GradStats-data'.

        Use forward slashes, even on Windows. Point at the folder that
        CONTAINS data, not at data itself. Then Run All. The output
        prints the folder back to you, so you can see it took.

        After that, any chapter's data is one line:

            !bookdata name = "ch09-ctt".

        The chapter tells you which name to use, in a note near its top.

STEP 2 (Julia).  include("load_data.jl"); d = book_data("ch09-ctt")
STEP 2 (Python). from load_data import book_data; d = book_data("ch09-ctt")

A NOTE ON CATEGORY ORDER. A .csv cannot record the order of a categorical
variable, so every language sorts them alphabetically - which would put
the fertilizer doses in the ANOVA chapter as high, low, none instead of
none, low, high, and attach the right numbers to the wrong labels. The
loaders fix this. In SPSS run the matching macro after loading, for
example !doseorder. after ch17-dose, or !petorder. after ch16-pets.

WHY THE DATA IS SHIPPED RATHER THAN SIMULATED. Random number generators
are not portable: the same seed gives different draws in R, Julia and
Python. If you regenerated these datasets in your own language, every
number you computed would sit a little off the ones printed in the book,
and you would reasonably assume you had made a mistake. So the data was
generated once, in R, and all four languages read the same files.

Built from the book source on 2026-08-05 - https://pem725.github.io/GradStats-Book/
