The Book's SPSS, Ready to Run - Statistics by Us for You
========================================================

Every SPSS block in the book, pulled out of the chapters into one syntax
file per chapter, with the data they need. Nothing here requires git or a
GitHub account.

WHAT IS IN HERE
  START-WINDOWS.cmd        double-click this on Windows after unzipping
  START-MAC.command        double-click this on a Mac after unzipping
  spss/00-CHECK-SETUP.sps  the starter opens this check
  spss/<chapter>.sps       one file per chapter, in book order
  data/                    every dataset the blocks read
  output/                  empty, for you to export output into

GETTING GOING
  1. Unzip this one file. It creates a folder named GradStats-SPSS.
  2. Double-click START-WINDOWS.cmd or START-MAC.command in that folder.
     The starter reads the folder's location and prepares every chapter.
     You do not type, copy, or edit any file path.
  3. In SPSS, choose Run All for 00-CHECK-SETUP.sps. The mean height should
     be about 67.99. Then open any chapter in spss/ and run it on its own.
  4. If you move the folder, run the starter again. The chapter files will
     be updated to the new location.

  If the starter does not open SPSS, open spss/00-CHECK-SETUP.sps from the
  SPSS File menu. On a Mac, allow the starter to open if macOS asks.

WHY WE ARE ASKING
  PSPP runs the executable SPSS blocks during the book render, but some
  IBM-only commands print PSPP errors, so a green build is not validation.
  Real IBM SPSS is the thing we cannot run here; your output will tell us
  which commands and results work in the software you actually teach.
  Where the two differ, the book was written to the smaller one - it uses
  PAF where SPSS would offer ML, and spells contrast codes out with COMPUTE
  because PSPP has no UNIANOVA /CONTRAST. Those choices are noted in the
  blocks. If real SPSS does something better, we want to know.

HOW BLOCKS ARE LABELLED
  Each block carries the chapter file and line it came from, so a problem
  can be traced straight back to the source:

      * BLOCK 3 of 6  |  Cronbach's Alpha, By Hand
      * source: 10-reliability.qmd line 120

  Two labels are worth knowing:

  [NEVER EXECUTED]  PSPP cannot run it, so the book prints it without ever
                    running it. No one has seen this work. If it runs for
                    you, that is new information.

  [NO CODE]         All comment, nothing to execute. The book uses these to
                    say plainly that base SPSS cannot do something and to
                    name the tool that can. Empty output is correct here.

RUN THESE FIRST - THE BLOCKS NOBODY HAS EVER SEEN WORK
  PSPP answers 'not yet implemented' to these, so every one is a command
  the book prints and cannot demonstrate. Real SPSS should run all of them.
  Measured against PSPP 2.0:

      15-MRC.sps            UNIANOVA    Type I and Type III sums of squares
      30-irt.sps            VARCOMP     variance components for G-theory
      20-beyond.sps         GRAPH /LINE the curve drawn over the data
      21-graphics.sps       GGRAPH      the modern SPSS chart engine
      21-graphics.sps       VARSTOCASES reshaping wide to long
      02-distributions.sps  GRAPH /LINE overlaying a curve on a histogram
      21-graphics.sps       GRAPH /LINE the same
      intro.sps             GRAPH /XYZ  the 3-D scatterplot

  UNIANOVA and VARCOMP are the two that matter most. They are ordinary SPSS
  and they carry real teaching weight - Type I versus Type III sums of
  squares is the whole point of that section of the regression chapter.
  If they run for you, please send the output.

A TRAP WORTH KNOWING
  A continuation line that BEGINS with an asterisk is read as a comment and
  silently dropped, because an asterisk in the command position starts one.
  Break long expressions so each operator ENDS its line instead. This cost
  the book a wrong number once already.

Built from the book source on 2026-09-25 - https://pem725.github.io/GradStats-Book/
