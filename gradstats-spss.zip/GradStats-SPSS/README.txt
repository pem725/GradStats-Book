The Book's SPSS, Ready to Run - Statistics by Us for You
========================================================

Every SPSS block in the book, pulled out of the chapters into one syntax
file per chapter, with the data they need. Nothing here requires git or a
GitHub account.

WHAT IS IN HERE
  spss/00-START-HERE.sps   run this first, once per session
  spss/<chapter>.sps       one file per chapter, in book order
  data/                    every dataset the blocks read
  output/                  empty, for you to export output into
  load_data.*              the R, SPSS, Julia and Python loaders

GETTING GOING
  1. Unzip somewhere you can find again. The Desktop is fine.
  2. Open spss/00-START-HERE.sps in SPSS. Put your own path in the CD line,
     uncomment it, and run the file. It prints the folder back to you.
  3. Open any chapter file and run it, whole or a block at a time.

WHY WE ARE ASKING
  Every SPSS block in the book has been checked against PSPP, which is free
  and which runs a SUBSET of SPSS. Real SPSS is the thing we cannot test.
  Where the two differ, the book was written to the smaller one - it uses
  PAF where SPSS would offer ML, and spells contrast codes out with COMPUTE
  because PSPP has no UNIANOVA /CONTRAST. Those choices are noted in the
  blocks. If real SPSS does something better, we want to know.

HOW BLOCKS ARE LABELLED
  Each block carries the chapter file and line it came from, so a problem
  can be traced straight back to the source:

      * BLOCK 3 of 6  |  Cronbach's Alpha, By Hand
      * source: 10-reliability.qmd line 120

  Two labels are worth knowing:

  [NEVER EXECUTED]  PSPP cannot run it, so the book prints it without ever
                    running it. No one has seen this work. If it runs for
                    you, that is new information.

  [NO CODE]         All comment, nothing to execute. The book uses these to
                    say plainly that base SPSS cannot do something and to
                    name the tool that can. Empty output is correct here.

RUN THESE FIRST - THE BLOCKS NOBODY HAS EVER SEEN WORK
  PSPP answers 'not yet implemented' to these, so every one is a command
  the book prints and cannot demonstrate. Real SPSS should run all of them.
  Measured against PSPP 2.0:

      15-MRC.sps            UNIANOVA    Type I and Type III sums of squares
      30-irt.sps            VARCOMP     variance components for G-theory
      20-beyond.sps         CREATE      lagged/generated series
      21-graphics.sps       GGRAPH      the modern SPSS chart engine
      21-graphics.sps       VARSTOCASES reshaping wide to long
      02-distributions.sps  GRAPH /LINE overlaying a curve on a histogram
      20-beyond.sps         GRAPH /LINE the same
      21-graphics.sps       GRAPH /LINE the same
      intro.sps             GRAPH /XYZ  the 3-D scatterplot

  UNIANOVA and VARCOMP are the two that matter most. They are ordinary SPSS
  and they carry real teaching weight - Type I versus Type III sums of
  squares is the whole point of that section of the regression chapter.
  If they run for you, please send the output.

A TRAP WORTH KNOWING
  A continuation line that BEGINS with an asterisk is read as a comment and
  silently dropped, because an asterisk in the command position starts one.
  Break long expressions so each operator ENDS its line instead. This cost
  the book a wrong number once already.

Built from the book source on 2026-09-01 - https://pem725.github.io/GradStats-Book/
