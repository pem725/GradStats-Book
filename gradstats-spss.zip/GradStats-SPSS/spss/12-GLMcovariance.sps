* ==========================================================================.
* Introducing the General Linear Model (GLM)
* Extracted from 12-GLMcovariance.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 1 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 1  |  The Same Answer, Three Ways
* source: 12-GLMcovariance.qmd line 53
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch12-groups.sps'.
* Same question, three ways: t-test, ANOVA, regression.
T-TEST GROUPS=group('control' 'treatment') /VARIABLES=y.
ONEWAY y BY group /STATISTICS DESCRIPTIVES.
REGRESSION /STATISTICS COEFF R ANOVA /DEPENDENT y /METHOD=ENTER group.

