* ==========================================================================.
* Causal Inference with DAGs
* Extracted from 33-causal.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 3 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It sets the working
* directory, without which none of the data paths below resolve.
* ==========================================================================.

* --------------------------------------------------------------------------.
* BLOCK 1 of 3  |  The Four Elemental Confounds
* source: 33-causal.qmd line 49
* --------------------------------------------------------------------------.
* PSPP has not implemented PARTIAL CORR, but a partial correlation IS the
* correlation between two sets of residuals, so we can build it directly -
* which is exactly what the R tab does.
INSERT FILE='data/sim/ch24-fork.sps'.

* The naive association.
CORRELATIONS /VARIABLES=X Y.

* Now control Z and correlate what is left over.
REGRESSION /DEPENDENT X /METHOD=ENTER Z /SAVE RESID.
REGRESSION /DEPENDENT Y /METHOD=ENTER Z /SAVE RESID.
CORRELATIONS /VARIABLES=RES1 RES2.

* --------------------------------------------------------------------------.
* BLOCK 2 of 3  |  The Four Elemental Confounds
* source: 33-causal.qmd line 101
* --------------------------------------------------------------------------.
* PSPP has not implemented PARTIAL CORR, but a partial correlation IS the
* correlation between two sets of residuals, so we can build it directly -
* which is exactly what the R tab does.
INSERT FILE='data/sim/ch24-pipe.sps'.

* The naive association.
CORRELATIONS /VARIABLES=X Y.

* Now control M and correlate what is left over.
REGRESSION /DEPENDENT X /METHOD=ENTER M /SAVE RESID.
REGRESSION /DEPENDENT Y /METHOD=ENTER M /SAVE RESID.
CORRELATIONS /VARIABLES=RES1 RES2.

* --------------------------------------------------------------------------.
* BLOCK 3 of 3  |  The Four Elemental Confounds
* source: 33-causal.qmd line 153
* --------------------------------------------------------------------------.
* PSPP has not implemented PARTIAL CORR, but a partial correlation IS the
* correlation between two sets of residuals, so we can build it directly -
* which is exactly what the R tab does.
INSERT FILE='data/sim/ch24-collider.sps'.

* The naive association.
CORRELATIONS /VARIABLES=X Y.

* Now control Z and correlate what is left over.
REGRESSION /DEPENDENT X /METHOD=ENTER Z /SAVE RESID.
REGRESSION /DEPENDENT Y /METHOD=ENTER Z /SAVE RESID.
CORRELATIONS /VARIABLES=RES1 RES2.

