* ==========================================================================.
* Case Study: The Data You Didn't Get
* Extracted from 26-casestudy-missing.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 1 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It defines !bookroot,
* which the next line uses to point SPSS at the folder holding data/.
* ==========================================================================.

* Re-anchors the working directory. Harmless to run twice, and it means this
* file works no matter what folder SPSS thinks it is in when you open it.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 1  |  The Twist: It Depends on What You're Estimating
* source: 26-casestudy-missing.qmd line 91
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch29-missing.sps'.
* Full-data slope of y on z.
REGRESSION /STATISTICS COEFF R ANOVA /DEPENDENT y /METHOD=ENTER z.
* Complete-case slope of y_obs on z (SPSS drops missing listwise by default).
REGRESSION /STATISTICS COEFF R ANOVA /DEPENDENT y_obs /METHOD=ENTER z.

