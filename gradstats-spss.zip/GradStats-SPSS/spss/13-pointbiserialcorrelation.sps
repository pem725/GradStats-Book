* ==========================================================================.
* Bridging the Gap: The Point Biserial Correlation
* Extracted from 13-pointbiserialcorrelation.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 2 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It sets the working
* directory, without which none of the data paths below resolve.
* ==========================================================================.

* --------------------------------------------------------------------------.
* BLOCK 1 of 2  |  The Trick: A Dichotomy Is Just 0 and 1
* source: 13-pointbiserialcorrelation.qmd line 42
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch13-study.sps'.
* point-biserial correlation: just Pearson r with a 0/1 variable.
CORRELATIONS /VARIABLES=score studied.

* --------------------------------------------------------------------------.
* BLOCK 2 of 2  |  The Same Thing, Wearing Three Hats
* source: 13-pointbiserialcorrelation.qmd line 90
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch13-study.sps'.
* (a) test the point-biserial correlation.
CORRELATIONS /VARIABLES=score studied.
* (b) the classic two-sample t-test (pooled variance).
T-TEST GROUPS=studied(0 1) /VARIABLES=score.
* (c) regression with the 0/1 predictor.
REGRESSION /STATISTICS COEFF R ANOVA /DEPENDENT score /METHOD=ENTER studied.

