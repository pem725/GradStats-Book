* ==========================================================================.
* Expectation and Understanding: The Z-Distribution
* Extracted from 06-zdistribution.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 1 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 1  |  Another Ruler: Percent of Maximum Possible (POMP)
* source: 06-zdistribution.qmd line 189
* --------------------------------------------------------------------------.
* POMP: 100 * (score - min) / (max - min), using each scale's own
* theoretical minimum and maximum, which travel with the data.
INSERT FILE='data/sim/ch05-pomp.sps'.

COMPUTE POMP = 100 * (score - lo) / (hi - lo).
EXECUTE.
LIST VARIABLES=measure score lo hi POMP.

