* ==========================================================================.
* Expectation and Understanding: The Z-Distribution
* Extracted from 06-zdistribution.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 1 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It sets the working
* directory, without which none of the data paths below resolve.
* ==========================================================================.

* --------------------------------------------------------------------------.
* BLOCK 1 of 1  |  Another Ruler: Percent of Maximum Possible (POMP)
* source: 06-zdistribution.qmd line 187
* --------------------------------------------------------------------------.
* POMP: 100 * (score - min) / (max - min), using each scale's own
* theoretical minimum and maximum, which travel with the data.
INSERT FILE='data/sim/ch05-pomp.sps'.

COMPUTE POMP = 100 * (score - lo) / (hi - lo).
EXECUTE.
LIST VARIABLES=measure score lo hi POMP.

