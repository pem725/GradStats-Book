* ==========================================================================.
* Validity (not Reliability)
* Extracted from 11-validity.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 1 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It sets the working
* directory, without which none of the data paths below resolve.
* ==========================================================================.

* --------------------------------------------------------------------------.
* BLOCK 1 of 1  |  Validity of the Measure
* source: 11-validity.qmd line 54
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch10-validity.sps'.
* Convergent vs discriminant validity as a correlation matrix.
CORRELATIONS
  /VARIABLES=new_scale old_scale verbal.

