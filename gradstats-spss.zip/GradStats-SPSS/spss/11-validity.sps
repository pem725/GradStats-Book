* ==========================================================================.
* Validity (not Reliability)
* Extracted from 11-validity.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 1 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It defines !bookroot,
* which the next line uses to point SPSS at the folder holding data/.
* ==========================================================================.

* Re-anchors the working directory. Harmless to run twice, and it means this
* file works no matter what folder SPSS thinks it is in when you open it.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 1  |  Validity of the Measure
* source: 11-validity.qmd line 54
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch10-validity.sps'.
* Convergent vs discriminant validity as a correlation matrix.
CORRELATIONS
  /VARIABLES=new_scale old_scale verbal.

