* ==========================================================================.
* Dispersion and Uncertainty
* Extracted from 04-Dmeasures.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 1 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 1  |  Standard Deviation: Back to Human Units
* source: 04-Dmeasures.qmd line 119
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch03-x.sps'.
DESCRIPTIVES VARIABLES=x
  /STATISTICS=STDDEV VARIANCE.

