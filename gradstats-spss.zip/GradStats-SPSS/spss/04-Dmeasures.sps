* ==========================================================================.
* Dispersion and Uncertainty
* Extracted from 04-Dmeasures.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 1 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It defines !bookroot,
* which the next line uses to point SPSS at the folder holding data/.
* ==========================================================================.

* Re-anchors the working directory. Harmless to run twice, and it means this
* file works no matter what folder SPSS thinks it is in when you open it.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 1  |  Standard Deviation: Back to Human Units
* source: 04-Dmeasures.qmd line 119
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch03-x.sps'.
DESCRIPTIVES VARIABLES=x
  /STATISTICS=STDDEV VARIANCE.

