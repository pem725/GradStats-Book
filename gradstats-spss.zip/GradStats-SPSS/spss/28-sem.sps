* ==========================================================================.
* Latent Variables: Confirmatory Factor Analysis and SEM
* Extracted from 28-sem.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 1 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It sets the working
* directory, without which none of the data paths below resolve.
* ==========================================================================.

* --------------------------------------------------------------------------.
* BLOCK 1 of 1  |  Factor Analysis, Executable
* source: 28-sem.qmd line 53
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch20-cfa.sps'.
* Factor analysis as a CFA proxy; a true CFA uses AMOS or the CFA/OMS approach.
* In SPSS the extraction line reads /EXTRACTION=ML, matching the R tab. PSPP
* offers PAF, PC and PA1 but not ML, so principal axis factoring runs here.
* The loadings agree with R's to the two decimals we print, though the sign of
* a factor is arbitrary - if a whole column comes out negative, nothing is
* wrong; the factor simply points the other way.
FACTOR
  /VARIABLES=a1 a2 a3 a4 b1 b2 b3 b4
  /EXTRACTION=PAF
  /CRITERIA=FACTORS(2)
  /ROTATION=PROMAX.

