* ==========================================================================.
* Coding Categorical Predictors
* Extracted from 19-coding.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 9 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 9  |  A Category Is a Binned Continuum
* source: 19-coding.qmd line 54
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch18-pets.sps'.

* Group means of happy by pet.
MEANS TABLES=happy BY pet
  /CELLS=MEAN STDDEV COUNT.

* --------------------------------------------------------------------------.
* BLOCK 2 of 9  |  Dummy (Reference) Coding
* source: 19-coding.qmd line 94
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch18-pets.sps'.

* Dummy / reference coding, reference = dog. Each code is 1 for its own
* group and 0 everywhere else, so dog - all three zero - is the baseline.
* In SPSS you would normally write
*   UNIANOVA happy BY pet /CONTRAST(pet)=SIMPLE(4) /PRINT=PARAMETER.
* PSPP has no /CONTRAST, so the codes are spelled out and handed to
* REGRESSION. For this chapter that is arguably the better view anyway:
* a coding scheme is nothing but a few columns of numbers, and here
* they are. The coefficients come out identical either way.

COMPUTE d_cat = (pet EQ 'cat').
COMPUTE d_fish = (pet EQ 'fish').
COMPUTE d_pig = (pet EQ 'pig').
EXECUTE.

REGRESSION /DEPENDENT=happy /METHOD=ENTER d_cat d_fish d_pig.


* --------------------------------------------------------------------------.
* BLOCK 3 of 9  |  Effects (Deviation) Coding
* source: 19-coding.qmd line 172
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch18-pets.sps'.

* Effects / deviation coding. Same 1s as dummy coding, but the omitted
* group gets -1 on every column, which moves the zero point from one
* group to the mean of the group means.
* In SPSS you would normally write
*   UNIANOVA happy BY pet /CONTRAST(pet)=DEVIATION /PRINT=PARAMETER.
* PSPP has no /CONTRAST, so the codes are spelled out and handed to
* REGRESSION. For this chapter that is arguably the better view anyway:
* a coding scheme is nothing but a few columns of numbers, and here
* they are. The coefficients come out identical either way.

COMPUTE e_cat = (pet EQ 'cat')  - (pet EQ 'dog').
COMPUTE e_fish = (pet EQ 'fish') - (pet EQ 'dog').
COMPUTE e_pig = (pet EQ 'pig')  - (pet EQ 'dog').
EXECUTE.

REGRESSION /DEPENDENT=happy /METHOD=ENTER e_cat e_fish e_pig.


* --------------------------------------------------------------------------.
* BLOCK 4 of 9  |  Helmert contrasts
* source: 19-coding.qmd line 313
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch18-pets.sps'.

* Helmert contrasts: each level against the mean of the levels after it.
* In SPSS you would normally write
*   UNIANOVA happy BY pet /CONTRAST(pet)=HELMERT /PRINT=PARAMETER.
* PSPP has no /CONTRAST, so the codes are spelled out and handed to
* REGRESSION. For this chapter that is arguably the better view anyway:
* a coding scheme is nothing but a few columns of numbers, and here
* they are. The coefficients come out identical either way.

COMPUTE h1 = -1*(pet EQ 'cat') + 1*(pet EQ 'fish').
COMPUTE h2 = -1*(pet EQ 'cat') - 1*(pet EQ 'fish') + 2*(pet EQ 'pig').
COMPUTE h3 = -1*(pet EQ 'cat') - 1*(pet EQ 'fish') - 1*(pet EQ 'pig') + 3*(pet EQ 'dog').
EXECUTE.

REGRESSION /DEPENDENT=happy /METHOD=ENTER h1 h2 h3.


* --------------------------------------------------------------------------.
* BLOCK 5 of 9  |  Custom orthogonal contrasts
* source: 19-coding.qmd line 386
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch18-pets.sps'.

* Custom orthogonal contrasts:
*   usual (cat, fish) vs unusual (pig, dog); cat vs fish; pig vs dog.
* In SPSS you would normally write
*   UNIANOVA happy BY pet
*     /CONTRAST(pet)=SPECIAL(0.5 0.5 -0.5 -0.5  0.5 -0.5 0 0  0 0 0.5 -0.5)
*     /PRINT=PARAMETER.
* PSPP has no /CONTRAST, so the codes are spelled out and handed to
* REGRESSION. For this chapter that is arguably the better view anyway:
* a coding scheme is nothing but a few columns of numbers, and here
* they are. The coefficients come out identical either way.

COMPUTE usual_vs_unusual = 0.5*(pet EQ 'cat') + 0.5*(pet EQ 'fish') - 0.5*(pet EQ 'pig') - 0.5*(pet EQ 'dog').
COMPUTE cat_vs_fish = 0.5*(pet EQ 'cat') - 0.5*(pet EQ 'fish').
COMPUTE pig_vs_dog = 0.5*(pet EQ 'pig') - 0.5*(pet EQ 'dog').
EXECUTE.

REGRESSION /DEPENDENT=happy /METHOD=ENTER usual_vs_unusual cat_vs_fish pig_vs_dog.


* --------------------------------------------------------------------------.
* BLOCK 6 of 9  |  Nonsense Coding
* source: 19-coding.qmd line 479
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch18-pets.sps'.

* Nonsense coding: arbitrary coefficients that answer no question anyone
* asked. The model still fits exactly as well - that is the point.
* In SPSS you would normally write
*   UNIANOVA happy BY pet
*     /CONTRAST(pet)=SPECIAL(3 -7 2.5 0.1  1 1 -2 4  -5 2 8 -1)
*     /PRINT=PARAMETER.
* PSPP has no /CONTRAST, so the codes are spelled out and handed to
* REGRESSION. For this chapter that is arguably the better view anyway:
* a coding scheme is nothing but a few columns of numbers, and here
* they are. The coefficients come out identical either way.

COMPUTE huh = 3*(pet EQ 'cat') - 7*(pet EQ 'fish') + 2.5*(pet EQ 'pig') + 0.1*(pet EQ 'dog').
COMPUTE wat = 1*(pet EQ 'cat') + 1*(pet EQ 'fish') - 2*(pet EQ 'pig') + 4*(pet EQ 'dog').
COMPUTE lol = -5*(pet EQ 'cat') + 2*(pet EQ 'fish') + 8*(pet EQ 'pig') - 1*(pet EQ 'dog').
EXECUTE.

REGRESSION /DEPENDENT=happy /METHOD=ENTER huh wat lol.


* --------------------------------------------------------------------------.
* BLOCK 7 of 9  |  A Real Example: Data From the GLM Course
* source: 19-coding.qmd line 585
* --------------------------------------------------------------------------.
INSERT FILE='data/mod3data.sps'.

* The grouping variable f3 codes its four groups 2, 3, 4, 5 - not 1 to 4.
* Groups A, B, C, D below are f3 = 2, 3, 4, 5 in that order.
MEANS TABLES=y1 BY f3
  /CELLS=MEAN STDDEV COUNT.

* --------------------------------------------------------------------------.
* BLOCK 8 of 9  |  A Real Example: Data From the GLM Course
* source: 19-coding.qmd line 631
* --------------------------------------------------------------------------.
INSERT FILE='data/mod3data.sps'.

* Dummy / reference coding, reference = group A. Remember f3 codes the
* groups 2, 3, 4, 5, so A is f3 = 2 and gets zeros on every column.
* In SPSS you would normally write
*   UNIANOVA y1 BY grp /CONTRAST(grp)=SIMPLE(1) /PRINT=PARAMETER.
* PSPP has no /CONTRAST, so the codes are spelled out and handed to
* REGRESSION. For this chapter that is arguably the better view anyway:
* a coding scheme is nothing but a few columns of numbers, and here
* they are. The coefficients come out identical either way.

COMPUTE d_B = (f3 EQ 3).
COMPUTE d_C = (f3 EQ 4).
COMPUTE d_D = (f3 EQ 5).
EXECUTE.

REGRESSION /DEPENDENT=y1 /METHOD=ENTER d_B d_C d_D.


* --------------------------------------------------------------------------.
* BLOCK 9 of 9  |  A Real Example: Data From the GLM Course
* source: 19-coding.qmd line 688
* --------------------------------------------------------------------------.
INSERT FILE='data/mod3data.sps'.

* Effects / deviation coding, with group D (f3 = 5) as the omitted group
* that carries -1 on every column.
* In SPSS you would normally write
*   UNIANOVA y1 BY grp /CONTRAST(grp)=DEVIATION /PRINT=PARAMETER.
* PSPP has no /CONTRAST, so the codes are spelled out and handed to
* REGRESSION. For this chapter that is arguably the better view anyway:
* a coding scheme is nothing but a few columns of numbers, and here
* they are. The coefficients come out identical either way.

COMPUTE e_A = (f3 EQ 2) - (f3 EQ 5).
COMPUTE e_B = (f3 EQ 3) - (f3 EQ 5).
COMPUTE e_C = (f3 EQ 4) - (f3 EQ 5).
EXECUTE.

REGRESSION /DEPENDENT=y1 /METHOD=ENTER e_A e_B e_C.


