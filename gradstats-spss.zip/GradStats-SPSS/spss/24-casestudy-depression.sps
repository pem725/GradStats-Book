* ==========================================================================.
* Case Study: When the Total Score Hides the Story
* Extracted from 24-casestudy-depression.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 4 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It defines !bookroot,
* which the next line uses to point SPSS at the folder holding data/.
* ==========================================================================.

* Re-anchors the working directory. Harmless to run twice, and it means this
* file works no matter what folder SPSS thinks it is in when you open it.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 4  |  How Much Does a Sum Score Hide?
* source: 24-casestudy-depression.qmd line 33
* --------------------------------------------------------------------------.
* How many 21-item profiles (each item 0..3) sum to exactly 15?
* Inclusion-exclusion, evaluated as a running total. SPSS has no
* binomial-coefficient function, so we build one out of LNGAMMA:
* choose(m, r) = EXP(LNGAMMA(m+1) - LNGAMMA(r+1) - LNGAMMA(m-r+1)).
DATA LIST FREE /dummy.
BEGIN DATA
1
END DATA.

COMPUTE k = 21.
COMPUTE a = 3.
COMPUTE n = 15.
COMPUTE total = 0.
LOOP #i = 0 TO TRUNC(n / (a + 1)).
  * Each operator ENDS its line on purpose: a continuation line that BEGINS
  * with an asterisk is read as a comment and silently dropped.
  COMPUTE total = total +
    ((-1) ** #i) *
    EXP(LNGAMMA(k+1) - LNGAMMA(#i+1) - LNGAMMA(k-#i+1)) *
    EXP(LNGAMMA(n - #i*(a+1) + k) - LNGAMMA(k) - LNGAMMA(n - #i*(a+1) + 1)).
END LOOP.
EXECUTE.
FORMATS total (COMMA16.0).
LIST VARIABLES=total.

* --------------------------------------------------------------------------.
* BLOCK 2 of 4  |  Same Score, Different People
* source: 24-casestudy-depression.qmd line 122
* --------------------------------------------------------------------------.
* Simulate 1200 people answering 21 graded (0..3) BDI-II-like items from a
* single latent severity dimension, then pull two who both scored 15.
* (Item names s1 to s21; theta is the person's latent severity.)
INPUT PROGRAM.
LOOP #p = 1 TO 1200.
  COMPUTE theta = RV.NORMAL(-0.5, 1).
  VECTOR s(21).
  LOOP #j = 1 TO 21.
    COMPUTE #d = 2.6 + 1.3 * IDF.NORMAL(#j / 22, 0, 1).
    COMPUTE s(#j) = (RV.UNIFORM(0,1) < (1/(1+EXP(-(theta - (#d - 1.1))))))
                  + (RV.UNIFORM(0,1) < (1/(1+EXP(-(theta - #d)))))
                  + (RV.UNIFORM(0,1) < (1/(1+EXP(-(theta - (#d + 1.1)))))).
  END LOOP.
  END CASE.
END LOOP.
END FILE.
END INPUT PROGRAM.
COMPUTE total = SUM(s1 TO s21).
EXECUTE.

TEMPORARY.
SELECT IF (total = 15).
LIST VARIABLES=s1 TO s21 /CASES=2.

* --------------------------------------------------------------------------.
* BLOCK 3 of 4  |  The Manifold Collapse
* source: 24-casestudy-depression.qmd line 221
* --------------------------------------------------------------------------.
* The book's simulated BDI-II-like responses: 1200 people, 21 items scored
* 0-3. Pull two people who both scored exactly 15.
INSERT FILE='data/sim/ch27-bdi.sps'.

COMPUTE total = SUM(sadness TO loss_sex_interest).
EXECUTE.

TEMPORARY.
SELECT IF (total = 15).
LIST VARIABLES=sadness pessimism past_failure loss_pleasure guilt /CASES=2.

* --------------------------------------------------------------------------.
* BLOCK 4 of 4  |  Antitypes: Profiles That Shouldn't Exist
* source: 24-casestudy-depression.qmd line 280
* --------------------------------------------------------------------------.
* How many distinct 21-item profiles actually occur among 1200 people?
INSERT FILE='data/sim/ch27-bdi.sps'.

STRING profile (A63).
COMPUTE profile = CONCAT(STRING(sadness,F1), STRING(pessimism,F1),
                         STRING(past_failure,F1), STRING(loss_pleasure,F1)).
EXECUTE.

AGGREGATE OUTFILE=* MODE=ADDVARIABLES /BREAK=profile /n_sharing=N.
FREQUENCIES VARIABLES=n_sharing.

