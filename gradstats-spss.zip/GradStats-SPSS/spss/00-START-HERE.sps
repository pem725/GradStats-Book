* ==========================================================================.
* START HERE. Run this once, at the beginning of every SPSS session.
*
* Put the location of THIS FOLDER between the quotes below, then delete the
* asterisk and the space at the start of that line, and run it.
*
* On a Mac the path looks like:
*     CD '/Users/yourname/Desktop/GradStats-SPSS'.
*
* Point at the folder that CONTAINS data and spss, not at either of them.
* Every chapter file assumes this has been done; none of them repeat it, so
* you edit one line here rather than one line in each of the 33 files.
* ==========================================================================.

* CD '/Users/yourname/Desktop/GradStats-SPSS'.

* Should print the folder holding data and spss. If it prints anything else,
* the line above is wrong and nothing after it will find its data.
SHOW DIRECTORY.

* OPTIONAL, and UNTESTED BY US - PSPP has no OMS, so we could not try it.
* Uncomment to have SPSS write everything to a plain text file you can send
* on, instead of reading it off the screen. Put OMSEND. at the end of the run.
*
* OMS /SELECT ALL /DESTINATION FORMAT=TEXT OUTFILE='output/session.txt'.
*
* Failing that, File > Export in the output window does the same job by hand.
