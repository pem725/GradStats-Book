* ==========================================================================.
* START HERE. Run this once, at the beginning of every SPSS session.
*
* ONE LINE TO EDIT. Put the location of THIS FOLDER between the quotes.
* Forward slashes, even on Windows:
*
*     Mac      '/Users/yourname/Desktop/GradStats-SPSS'
*     Windows  'C:/Users/yourname/Dropbox/GradStats-SPSS'
*
* Point at the folder that CONTAINS data and spss. Do NOT put /data or
* /spss on the end. That is the commonest way to get this wrong, and the
* error it causes does not say so.
*
* Your own syntax files can live anywhere. Every chapter file re-anchors
* itself with CD !bookroot, so it does not matter what folder SPSS thinks
* it is in.
* ==========================================================================.

DEFINE !bookroot () 'C:/path/to/GradStats-SPSS' !ENDDEFINE.

CD !bookroot.
SHOW DIRECTORY.

* CHECK IT. Run this line:   !bookcheck.
* A mean height of about 67.99 means everything is wired up. Anything else
* means !bookroot above is wrong.
DEFINE !bookcheck ()
CD !bookroot.
SHOW DIRECTORY.
INSERT FILE = 'data/sim/ch01-heights.sps'.
DESCRIPTIVES VARIABLES=height /STATISTICS=MEAN.
!ENDDEFINE.

* OPTIONAL, and UNTESTED BY US - PSPP has no OMS, so we could not try it.
* Uncomment to have SPSS write everything to a plain text file you can send
* on, instead of reading it off the screen. Put OMSEND. at the end of the run.
*
* OMS /SELECT ALL /DESTINATION FORMAT=TEXT OUTFILE='output/session.txt'.
*
* Failing that, File > Export in the output window does the same job by hand.
