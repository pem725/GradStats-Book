* ==========================================================================.
* Measurement Invariance: Does the Ruler Mean the Same Thing for Everyone?
* Extracted from 32-invariance.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 1 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 1  |  The Artifact You Are Guarding Against
* source: 32-invariance.qmd line 51
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch21-invariance.sps'.
* Assumes the active dataset holds the true trait, the composite score, and the group factor grp.
* Group means: true trait (equal by construction) and observed composite, by group.
MEANS TABLES=trait composite BY grp /CELLS=MEAN STDDEV COUNT.
* Independent-groups (Welch) t-test comparing the composite across groups.
T-TEST GROUPS=grp('A' 'B') /VARIABLES=composite.

