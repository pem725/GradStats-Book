* ==========================================================================.
* Testing Hypotheses with Data
* Extracted from 08-hypothesistesting.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 2 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 2  |  The Machinery: A Worked Example
* source: 08-hypothesistesting.qmd line 72
* --------------------------------------------------------------------------.
* The standard error, z, and one-tailed p for a sample mean of 22
* against a null mean of 20 with sigma = 4 and n = 4.
DATA LIST FREE /mu sigma n xbar.
BEGIN DATA
20 4 4 22
END DATA.

COMPUTE standard_error = sigma / SQRT(n).
COMPUTE z = (xbar - mu) / standard_error.
COMPUTE p_value = 1 - CDF.NORMAL(z, 0, 1).
EXECUTE.
LIST VARIABLES=standard_error z p_value.

* --------------------------------------------------------------------------.
* BLOCK 2 of 2  |  The Machinery: A Worked Example
* source: 08-hypothesistesting.qmd line 139
* --------------------------------------------------------------------------.
* Simulate 10,000 sample means of n = 4 from the H0 world (mu = 20, sigma = 4)
* and see where the observed 22 lands.
INPUT PROGRAM.
LOOP #i = 1 TO 10000.
  COMPUTE sample_mean = MEAN(RV.NORMAL(20, 4), RV.NORMAL(20, 4),
                             RV.NORMAL(20, 4), RV.NORMAL(20, 4)).
  END CASE.
END LOOP.
END FILE.
END INPUT PROGRAM.
EXECUTE.

GRAPH /HISTOGRAM = sample_mean.

