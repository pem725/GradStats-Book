* ==========================================================================.
* Multiple Regression
* Extracted from 15-MRC.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 6 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It defines !bookroot,
* which the next line uses to point SPSS at the folder holding data/.
* ==========================================================================.

* Re-anchors the working directory. Harmless to run twice, and it means this
* file works no matter what folder SPSS thinks it is in when you open it.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 6  |  Some Deliberately Tangled Data
* source: 15-MRC.qmd line 47
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch15-tangled.sps'.
CORRELATIONS /VARIABLES=y x1 x2.

* --------------------------------------------------------------------------.
* BLOCK 2 of 6  |  Some Deliberately Tangled Data
* source: 15-MRC.qmd line 77
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch15-tangled.sps'.
REGRESSION /STATISTICS COEFF R ANOVA /DEPENDENT y /METHOD=ENTER x1 x2.

* --------------------------------------------------------------------------.
* BLOCK 3 of 6  |  Three Things People Confuse
* source: 15-MRC.qmd line 138
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch15-tangled.sps'.
* REGRESSION prints the standardized Beta by default.
REGRESSION /STATISTICS COEFF R ANOVA /DEPENDENT y /METHOD=ENTER x1 x2.

* --------------------------------------------------------------------------.
* BLOCK 4 of 6  |  Partitioning Variance: Types of Sums of Squares
* source: 15-MRC.qmd line 297
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch15-typess.sps'.
* Type I (sequential) sums of squares; DESIGN order sets the entry order.
UNIANOVA y WITH x1 x2 /METHOD=SSTYPE(1) /DESIGN=x1 x2.
UNIANOVA y WITH x1 x2 /METHOD=SSTYPE(1) /DESIGN=x2 x1.

* --------------------------------------------------------------------------.
* BLOCK 5 of 6  |  Partitioning Variance: Types of Sums of Squares
* source: 15-MRC.qmd line 353
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch15-typess.sps'.
* Type III (unique / "each last") sums of squares; SPSS's default.
UNIANOVA y WITH x1 x2 /METHOD=SSTYPE(3) /DESIGN=x1 x2.

* --------------------------------------------------------------------------.
* BLOCK 6 of 6  |  A Real Example: Predicting College GPA
* source: 15-MRC.qmd line 452
* --------------------------------------------------------------------------.
GET DATA /TYPE=TXT /FILE='data/gpa.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=CollegeGPA F16.6 HSGPA F16.6 SATtotal F16.6 QLOR F16.6.
REGRESSION /STATISTICS COEFF R ANOVA
  /DEPENDENT CollegeGPA /METHOD=ENTER HSGPA SATtotal QLOR.

