* ==========================================================================.
* Beyond the Normal Curve: Resampling, Robust, and Bayesian Statistics
* Extracted from 20-beyond.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 10 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 10  |  The bootstrap (estimation)
* source: 20-beyond.qmd line 83
* --------------------------------------------------------------------------.
* Real SPSS bootstraps with the Bootstrapping add-on module:
*   BOOTSTRAP /SAMPLING METHOD=SIMPLE /VARIABLES TARGET=samp
*     /CRITERIA CILEVEL=95 NSAMPLES=2000 CITYPE=PERCENTILE.
*   DESCRIPTIVES VARIABLES=samp /STATISTICS=MEAN.
* PSPP has not implemented BOOTSTRAP, so what runs here is the estimate the
* bootstrap is built around - the sample mean and its normal-theory interval.
INSERT FILE='data/sim/ch25-skewed-sample.sps'.

EXAMINE VARIABLES=samp /STATISTICS=DESCRIPTIVES.

* --------------------------------------------------------------------------.
* BLOCK 2 of 10  |  The bootstrap (estimation)
* source: 20-beyond.qmd line 142
* --------------------------------------------------------------------------.
* With the Bootstrapping module you would save the resampled estimates and
* histogram them. Without it, the honest picture PSPP can draw is the sample
* the bootstrap resamples FROM.
INSERT FILE='data/sim/ch25-skewed-sample.sps'.

GRAPH /HISTOGRAM(NORMAL) = samp.

* --------------------------------------------------------------------------.
* BLOCK 3 of 10  |  The permutation test (testing)
* source: 20-beyond.qmd line 210
* --------------------------------------------------------------------------.
* Base SPSS has no mean-difference permutation test. The Exact Tests module
* applies the same shuffling logic to rank procedures, and PSPP can run the
* Monte-Carlo Mann-Whitney, which is that idea on ranks:
INSERT FILE='data/sim/ch25-twogroups.sps'.

NPAR TESTS
  /M-W = value BY group(1 2)
  /MISSING ANALYSIS.

* --------------------------------------------------------------------------.
* BLOCK 4 of 10  |  The jackknife (a leave-one-out cousin)
* source: 20-beyond.qmd line 272
* --------------------------------------------------------------------------.
* Base SPSS has no jackknife, but leave-one-out is easy arithmetic: the mean
* without case i is (total - x_i) / (n - 1).
INSERT FILE='data/sim/ch25-skewed-sample.sps'.

COMPUTE whole = 1.
AGGREGATE OUTFILE=* MODE=ADDVARIABLES /BREAK=whole /grand=SUM(samp) /n=N.
COMPUTE loo_mean = (grand - samp) / (n - 1).
EXECUTE.

DESCRIPTIVES VARIABLES=loo_mean /STATISTICS=MEAN STDDEV.

* --------------------------------------------------------------------------.
* BLOCK 5 of 10  |  Part 2 · Robust Statistics: When a Few Points Hijack the Mean
* source: 20-beyond.qmd line 333
* --------------------------------------------------------------------------.
* Nineteen clean observations and one data-entry error. EXAMINE reports the
* mean, median, the 5% trimmed mean and the SD in one table.
INSERT FILE='data/sim/ch25-outlier.sps'.

EXAMINE VARIABLES=z /STATISTICS=DESCRIPTIVES.

* --------------------------------------------------------------------------.
* BLOCK 6 of 10  |  Why it matters: the arithmetic of the replication crisis
* source: 20-beyond.qmd line 406
* --------------------------------------------------------------------------.
* Bayes' rule applied to a screening question: given power, alpha, and a
* prior, what is the posterior probability the hypothesis is true?
DATA LIST FREE /power alpha prior.
BEGIN DATA
0.99 0.01 0.02
END DATA.

COMPUTE posterior = (power * prior) / (power * prior + alpha * (1 - prior)).
EXECUTE.
LIST VARIABLES=power alpha prior posterior.

* --------------------------------------------------------------------------.
* BLOCK 7 of 10  |  Why it matters: the arithmetic of the replication crisis
* source: 20-beyond.qmd line 444
* --------------------------------------------------------------------------.
* Modest power, ordinary screening, a rarer idea.
DATA LIST FREE /power alpha prior.
BEGIN DATA
0.95 0.05 0.01
END DATA.

COMPUTE posterior = (power * prior) / (power * prior + alpha * (1 - prior)).
EXECUTE.
LIST VARIABLES=posterior.

* --------------------------------------------------------------------------.
* BLOCK 8 of 10  |  Building a posterior by hand (grid approximation)
* source: 20-beyond.qmd line 493
* --------------------------------------------------------------------------.
* Grid approximation of a posterior for a proportion after 6 successes
* in 9 trials, with a Beta(2,2) prior.
INPUT PROGRAM.
LOOP #i = 0 TO 1000.
  COMPUTE theta = #i / 1000.
  COMPUTE prior = PDF.BETA(theta, 2, 2).
  COMPUTE like  = PDF.BINOM(6, 9, theta).
  COMPUTE post  = like * prior.
  END CASE.
END LOOP.
END FILE.
END INPUT PROGRAM.
EXECUTE.

* Normalise, then plot.
COMPUTE whole = 1.
AGGREGATE OUTFILE=* MODE=ADDVARIABLES /BREAK=whole /tot=SUM(post).
COMPUTE post = post / tot.
EXECUTE.

GRAPH /LINE(SIMPLE) = VALUE(post) BY theta.

* --------------------------------------------------------------------------.
* BLOCK 9 of 10  |  Building a posterior by hand (grid approximation)
* source: 20-beyond.qmd line 561
* --------------------------------------------------------------------------.
* Sampling from the grid posterior needs a weighted draw, which base SPSS
* does not offer directly. The quantiles can instead be read off the grid
* itself, which is exact rather than simulated: the 2.5th and 97.5th
* percentiles are where the CUMULATIVE posterior crosses 0.025 and 0.975.
*
* The grid is rebuilt here rather than carried over. Each tab in this book
* runs in its own process, so a tab that referred back to the one above
* would find no data at all.
INPUT PROGRAM.
LOOP #i = 0 TO 1000.
  COMPUTE theta = #i / 1000.
  COMPUTE prior = PDF.BETA(theta, 2, 2).
  COMPUTE like  = PDF.BINOM(6, 9, theta).
  COMPUTE post  = like * prior.
  END CASE.
END LOOP.
END FILE.
END INPUT PROGRAM.

* Normalise, so the grid is a probability distribution rather than a shape.
COMPUTE one = 1.
AGGREGATE OUTFILE=* MODE=ADDVARIABLES /BREAK=one /tot=SUM(post).
COMPUTE post = post / tot.

* Running total. A scratch variable (the # prefix) keeps its value from one
* case to the next, which is how SPSS accumulates down a column without
* IBM's CREATE/CSUM - and it runs everywhere, including PSPP.
COMPUTE #run = #run + post.
COMPUTE cum_post = #run.
EXECUTE.

TEMPORARY.
SELECT IF (cum_post >= 0.025 AND cum_post <= 0.975).
DESCRIPTIVES VARIABLES=theta /STATISTICS=MINIMUM MAXIMUM.

* --------------------------------------------------------------------------.
* BLOCK 10 of 10  |  Building a posterior by hand (grid approximation)
* source: 20-beyond.qmd line 635
* --------------------------------------------------------------------------.
* The posterior probability inside a region of practical equivalence
* (here 0.45 to 0.55, "practically a fair coin"). On the grid this is
* simply the posterior mass between those two values.
*
* The grid is rebuilt here for the same reason as the tab above: every tab
* runs in its own process and inherits nothing.
INPUT PROGRAM.
LOOP #i = 0 TO 1000.
  COMPUTE theta = #i / 1000.
  COMPUTE prior = PDF.BETA(theta, 2, 2).
  COMPUTE like  = PDF.BINOM(6, 9, theta).
  COMPUTE post  = like * prior.
  END CASE.
END LOOP.
END FILE.
END INPUT PROGRAM.

* Normalise first, or the "probability" below is just an unscaled sum.
COMPUTE one = 1.
AGGREGATE OUTFILE=* MODE=ADDVARIABLES /BREAK=one /tot=SUM(post).
COMPUTE post = post / tot.
EXECUTE.

TEMPORARY.
SELECT IF (theta > 0.45 AND theta < 0.55).
DESCRIPTIVES VARIABLES=post /STATISTICS=SUM.

