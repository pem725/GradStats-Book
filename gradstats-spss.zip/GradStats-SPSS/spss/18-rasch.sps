* ==========================================================================.
* Measuring Like Ben Wright: Rasch in R, Python, and Julia
* Extracted from 18-rasch.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 4 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 4  |  Wright's Data: The Knox Cube Test
* source: 18-rasch.qmd line 58
* --------------------------------------------------------------------------.
* Wright's Knox Cube Test responses: 35 children (rows) by 18 tapping items
* (columns), 1 = repeated the tapping pattern correctly. The loader is in
* data/knox.sps, which spells out the format for all eighteen items.
INSERT FILE='data/knox.sps'.

LIST VARIABLES=Name i1 TO i9 /CASES=6.

* --------------------------------------------------------------------------.
* BLOCK 2 of 4  |  Wright's Data: The Knox Cube Test
* source: 18-rasch.qmd line 101
* --------------------------------------------------------------------------.
INSERT FILE='data/knox.sps'.

* Passes per item, easy (left) to hard (right). Everyone passes the first
* three and no one passes the last - those carry no information about
* DIFFERENCES, and cannot get a finite logit.
DESCRIPTIVES VARIABLES=i1 TO i18 /STATISTICS=SUM.

* --------------------------------------------------------------------------.
* BLOCK 3 of 4  |  The Engine: Joint Maximum Likelihood (What BIGSTEPS Does)
* source: 18-rasch.qmd line 189  [NO CODE - base SPSS cannot do this; the block says what can]
* --------------------------------------------------------------------------.
* Base SPSS has no Rasch or IRT procedure. Item calibration needs a
* dedicated engine - Winsteps/BIGSTEPS (Wright's own), ConQuest, or R's
* eRm/TAM - or the SPSS Python/R integration plug-in calling one of those.
*
* The joint-maximum-likelihood calibration of item difficulties is shown in
* the R, Julia and Python tabs.

* --------------------------------------------------------------------------.
* BLOCK 4 of 4  |  The Engine: Joint Maximum Likelihood (What BIGSTEPS Does)
* source: 18-rasch.qmd line 300  [NO CODE - base SPSS cannot do this; the block says what can]
* --------------------------------------------------------------------------.
* Base SPSS has no Rasch or IRT procedure. Item calibration needs a
* dedicated engine - Winsteps/BIGSTEPS (Wright's own), ConQuest, or R's
* eRm/TAM - or the SPSS Python/R integration plug-in calling one of those.
*
* The person measures (abilities) are shown in the R, Julia and Python tabs.

