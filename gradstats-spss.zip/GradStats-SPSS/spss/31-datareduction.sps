* ==========================================================================.
* Data Reduction: Fewer, Better Measures
* Extracted from 31-datareduction.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 2 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It defines !bookroot,
* which the next line uses to point SPSS at the folder holding data/.
* ==========================================================================.

* Re-anchors the working directory. Harmless to run twice, and it means this
* file works no matter what folder SPSS thinks it is in when you open it.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 2  |  Test the Structure Before You Combine
* source: 31-datareduction.qmd line 105
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch19-items.sps'.
FACTOR /VARIABLES x1 x2 x3 x4 x5 x6 /EXTRACTION PC /PRINT INITIAL EXTRACTION /PLOT EIGEN.

* --------------------------------------------------------------------------.
* BLOCK 2 of 2  |  Test the Structure Before You Combine
* source: 31-datareduction.qmd line 142
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch19-items.sps'.

* In SPSS this reads /EXTRACTION=ML, which is what the R tab's factanal()
* does. PSPP - the free engine this book renders with - offers PAF, PC and
* PA1 but not ML, so principal axis factoring is what runs here. On this data
* the two agree to the two decimals we print.
FACTOR
  /VARIABLES=x1 x2 x3 x4 x5 x6
  /EXTRACTION=PAF
  /CRITERIA=FACTORS(1)
  /PRINT=INITIAL EXTRACTION.

