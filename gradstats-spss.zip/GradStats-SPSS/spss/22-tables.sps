* ==========================================================================.
* Displaying Data: Tables
* Extracted from 22-tables.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 4 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 4  |  When a Table Beats a Graph
* source: 22-tables.qmd line 45
* --------------------------------------------------------------------------.
* Summarise 42 years down to five decade averages.
GET DATA /TYPE=TXT /FILE='data/mlb_league_by_year.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=year F16.6 OPS F16.6 K_PA F16.6 BB_PA F16.6 HR_PA F16.6 AVG F16.6 ERA F16.6 K_9 F16.6 BB_9 F16.6 HR_9 F16.6.

COMPUTE decade = TRUNC(year / 10) * 10.
FORMATS decade (F4.0).
EXECUTE.

MEANS TABLES=K_9 BB_9 HR_9 AVG BY decade
  /CELLS=MEAN.

* --------------------------------------------------------------------------.
* BLOCK 2 of 4  |  Kill False Precision
* source: 22-tables.qmd line 100
* --------------------------------------------------------------------------.
* False precision: every digit the machine produced.
GET DATA /TYPE=TXT /FILE='data/nfl_draft_by_team.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=team A24 n_picks F16.6 n_judged F16.6 n_hof F16.6 n_bust_a F16.6 n_bust_b F16.6 n_bust_c F16.6 n_triple_bust F16.6 n_clean_hit F16.6 rate_bust_a F16.6 rate_bust_b F16.6 rate_bust_c F16.6 rate_triple_bust F16.6 rate_clean_hit F16.6 hof_per_pick F16.6.

SORT CASES BY rate_bust_a (D).
* SPSS shows whatever the variable's FORMAT allows - widen it and the
* spurious digits appear:
FORMATS rate_bust_a rate_clean_hit (F8.4).
LIST VARIABLES=team n_picks rate_bust_a rate_clean_hit /CASES=4.

* --------------------------------------------------------------------------.
* BLOCK 3 of 4  |  Kill False Precision
* source: 22-tables.qmd line 145
* --------------------------------------------------------------------------.
GET DATA /TYPE=TXT /FILE='data/nfl_draft_by_team.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=team A24 n_picks F16.6 n_judged F16.6 n_hof F16.6 n_bust_a F16.6 n_bust_b F16.6 n_bust_c F16.6 n_triple_bust F16.6 n_clean_hit F16.6 rate_bust_a F16.6 rate_bust_b F16.6 rate_bust_c F16.6 rate_triple_bust F16.6 rate_clean_hit F16.6 hof_per_pick F16.6.
* Honest precision: whole percentages, rounded to what the sample supports.
COMPUTE rate_bust_a    = RND(100 * rate_bust_a).
COMPUTE rate_clean_hit = RND(100 * rate_clean_hit).
FORMATS rate_bust_a rate_clean_hit (F3.0).
VARIABLE LABELS rate_bust_a 'Bust rate (%)'
                rate_clean_hit 'Clean-hit rate (%)'.
EXECUTE.

LIST VARIABLES=team n_picks rate_bust_a rate_clean_hit /CASES=4.

* --------------------------------------------------------------------------.
* BLOCK 4 of 4  |  Order Rows to Carry Information
* source: 22-tables.qmd line 207
* --------------------------------------------------------------------------.
GET DATA /TYPE=TXT /FILE='data/nfl_draft_by_team.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=team A24 n_picks F16.6 n_judged F16.6 n_hof F16.6 n_bust_a F16.6 n_bust_b F16.6 n_bust_c F16.6 n_triple_bust F16.6 n_clean_hit F16.6 rate_bust_a F16.6 rate_bust_b F16.6 rate_bust_c F16.6 rate_triple_bust F16.6 rate_clean_hit F16.6 hof_per_pick F16.6.
* Show the two ends of the ranking, not all 32 rows.
* Flag the top and bottom five, then list only those.
COMPUTE rank_bust = $CASENUM.
COMPUTE ends = 0.
IF (rank_bust <= 5) ends = 1.
IF (rank_bust > 27) ends = 2.
VALUE LABELS ends 1 'Worst drafters' 2 'Best drafters'.
EXECUTE.

TEMPORARY.
SELECT IF (ends > 0).
LIST VARIABLES=ends team n_picks rate_bust_a.

