* ==========================================================================.
* Latent Classes: Which Kind of Person Is This?
* Extracted from 29-latentclass.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 3 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It sets the working
* directory, without which none of the data paths below resolve.
* ==========================================================================.

* --------------------------------------------------------------------------.
* BLOCK 1 of 3  |  Fitting It From Scratch with EM
* source: 29-latentclass.qmd line 54
* --------------------------------------------------------------------------.
* The book's two-class data: 800 people, 8 binary items, with items 7-8
* reversed so the classes differ in PATTERN rather than severity.
INSERT FILE='data/sim/ch22-lca.sps'.

DESCRIPTIVES VARIABLES=x1 TO x8 /STATISTICS=MEAN.

* --------------------------------------------------------------------------.
* BLOCK 2 of 3  |  Fitting It From Scratch with EM
* source: 29-latentclass.qmd line 109
* --------------------------------------------------------------------------.
* Base SPSS has no latent class analysis, and neither does PSPP. A genuine
* LCA needs Latent GOLD, Mplus, or R's poLCA; SPSS's own nearest relative is
* TwoStep Cluster, which groups cases but estimates no class-conditional item
* probabilities and no membership posteriors.
*
* What SPSS CAN show is the raw endorsement rate of each item, which is the
* marginal the mixture model decomposes:
INSERT FILE='data/sim/ch22-lca.sps'.

DESCRIPTIVES VARIABLES=x1 TO x8 /STATISTICS=MEAN.

* --------------------------------------------------------------------------.
* BLOCK 3 of 3  |  Fitting It From Scratch with EM
* source: 29-latentclass.qmd line 190  [NO CODE - base SPSS cannot do this; the block says what can]
* --------------------------------------------------------------------------.
* The item-probability profiles - the DEFINITIONS of the two kinds - are
* exactly what an LCA produces and SPSS cannot. See the note above; the R,
* Julia and Python tabs estimate them from scratch with EM.

