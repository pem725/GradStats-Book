* ==========================================================================.
* The Best Guess
* Extracted from 03-CTmeasures.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 2 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 2  |  Three Ways to Say "Typical"
* source: 03-CTmeasures.qmd line 36
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch02-x.sps'.
FREQUENCIES VARIABLES=x /STATISTICS=MEAN MEDIAN MODE.

* --------------------------------------------------------------------------.
* BLOCK 2 of 2  |  When the Mean Lies
* source: 03-CTmeasures.qmd line 147
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch02-income.sps'.
FREQUENCIES VARIABLES=income /STATISTICS=MEAN MEDIAN.

