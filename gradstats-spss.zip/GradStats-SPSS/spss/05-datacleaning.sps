* ==========================================================================.
* Cleaning House
* Extracted from 05-datacleaning.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 2 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 2  |  Impossible Values and Sanity Checks
* source: 05-datacleaning.qmd line 60
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch04-dirty.sps'.

* Recode impossible and coded-missing values to system-missing.
RECODE age (121 THRU HIGHEST=SYSMIS).
RECODE income (LOWEST THRU -0.001=SYSMIS) (999=SYSMIS).
* Fix "b" and stray spaces in group.
COMPUTE group = UPCASE(LTRIM(RTRIM(group))).
EXECUTE.
* Frequency table of the cleaned group variable (missing shown by default).
FREQUENCIES VARIABLES=group.

* --------------------------------------------------------------------------.
* BLOCK 2 of 2  |  Missing Data: The *Why* Matters
* source: 05-datacleaning.qmd line 112
* --------------------------------------------------------------------------.
* Real SPSS answers this with MVA VARIABLES=ALL, a dedicated missing-value
* analysis. PSPP has not implemented MVA, and FREQUENCIES reports the same
* valid/missing counts, so that is what runs here.
INSERT FILE='data/sim/ch04-dirty.sps'.

FREQUENCIES VARIABLES=age income group.

