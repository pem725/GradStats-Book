* ==========================================================================.
* The Same Analysis in R, SPSS, Julia, and Python
* Extracted from three-languages.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 6 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It sets the working
* directory, without which none of the data paths below resolve.
* ==========================================================================.

* --------------------------------------------------------------------------.
* BLOCK 1 of 6  |  Descriptive Statistics
* source: three-languages.qmd line 43
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/appendix-d.sps'.
DESCRIPTIVES VARIABLES=x y
  /STATISTICS=MEAN STDDEV MIN MAX.

* --------------------------------------------------------------------------.
* BLOCK 2 of 6  |  Correlation
* source: three-languages.qmd line 74
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/appendix-d.sps'.
CORRELATIONS
  /VARIABLES=x y.

* --------------------------------------------------------------------------.
* BLOCK 3 of 6  |  Comparing Two Groups (t-test)
* source: three-languages.qmd line 108
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/appendix-d.sps'.
T-TEST GROUPS=group('A' 'B')
  /VARIABLES=y.

* --------------------------------------------------------------------------.
* BLOCK 4 of 6  |  Linear Regression
* source: three-languages.qmd line 140
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/appendix-d.sps'.
REGRESSION
  /DEPENDENT y
  /METHOD=ENTER x.

* --------------------------------------------------------------------------.
* BLOCK 5 of 6  |  One-Way ANOVA
* source: three-languages.qmd line 176
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/appendix-d.sps'.
ONEWAY y BY group
  /STATISTICS DESCRIPTIVES.

* --------------------------------------------------------------------------.
* BLOCK 6 of 6  |  Principal Components
* source: three-languages.qmd line 218
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/appendix-items.sps'.
FACTOR
  /VARIABLES item1 item2 item3 item4
  /EXTRACTION PC
  /PRINT INITIAL EXTRACTION
  /ROTATION VARIMAX.

