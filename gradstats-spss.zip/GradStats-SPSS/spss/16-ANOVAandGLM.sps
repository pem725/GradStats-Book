* ==========================================================================.
* ANOVA and the General Linear Model
* Extracted from 16-ANOVAandGLM.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 3 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 3  |  A Categorical Predictor Is a Sliced-Up Continuous One
* source: 16-ANOVAandGLM.qmd line 51
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch16-pets.sps'.
ONEWAY happy BY pet /STATISTICS DESCRIPTIVES.

* --------------------------------------------------------------------------.
* BLOCK 2 of 3  |  Two Categorical Predictors and Their Interaction
* source: 16-ANOVAandGLM.qmd line 192
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch16-pets.sps'.

* GLM and UNIANOVA are the same procedure in SPSS; GLM is the name that also
* works in PSPP, so that is what the book runs. A factor has to be numeric
* here, which is what AUTORECODE does - it hands back the same groups with
* integer codes and the labels still attached.
AUTORECODE VARIABLES=pet mess /INTO petn messn.

GLM sad BY petn messn
  /DESIGN=petn messn petn*messn.

* --------------------------------------------------------------------------.
* BLOCK 3 of 3  |  Beyond the Straight Line: The *Generalized* Linear Model
* source: 16-ANOVAandGLM.qmd line 237
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch16-pets.sps'.
LOGISTIC REGRESSION VARIABLES passed WITH x.

