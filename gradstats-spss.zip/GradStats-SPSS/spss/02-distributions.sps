* ==========================================================================.
* Variables and Distributions
* Extracted from 02-distributions.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 5 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 5  |  Representing Variables Numerically
* source: 02-distributions.qmd line 68
* --------------------------------------------------------------------------.
* Categories live as string values with VALUE LABELS attached; the labels
* travel with the data the way an R factor's levels do.
DATA LIST LIST /flavor (A6).
BEGIN DATA
choc
van
choc
straw
van
END DATA.

* AUTORECODE exposes the integer codes sitting under the labels.
AUTORECODE VARIABLES=flavor /INTO flavor_code.
* What we actually care about: the counts.
FREQUENCIES VARIABLES=flavor.

* --------------------------------------------------------------------------.
* BLOCK 2 of 5  |  Histograms
* source: 02-distributions.qmd line 130
* --------------------------------------------------------------------------.
* The book's own 500 heights, then the histogram with a normal curve on it.
* (NORMAL) asks SPSS to overlay the fitted normal, the same curve the R tab
* draws from the parameters.
INSERT FILE='data/sim/ch01-heights.sps'.

GRAPH /HISTOGRAM(NORMAL) = height.

* --------------------------------------------------------------------------.
* BLOCK 3 of 5  |  Shapes
* source: 02-distributions.qmd line 213
* --------------------------------------------------------------------------.
* The book's skew-normal draws. The construction - two normal draws, one of
* them folded positive - is spelled out in the R tab; here we read the same
* 1000 values so the picture matches.
INSERT FILE='data/sim/ch01-skewed.sps'.

GRAPH /HISTOGRAM(NORMAL) = value.

* --------------------------------------------------------------------------.
* BLOCK 4 of 5  |  Names for Shapes
* source: 02-distributions.qmd line 317
* --------------------------------------------------------------------------.
* The book's own 1000 draws from each shape. SPSS has no faceting, so each
* shape gets its own GRAPH command.
INSERT FILE='data/sim/ch01-shapes.sps'.

GRAPH /HISTOGRAM(NORMAL) = Normal.
GRAPH /HISTOGRAM = Uniform.
GRAPH /HISTOGRAM = Binomial.
GRAPH /HISTOGRAM = Poisson.

* --------------------------------------------------------------------------.
* BLOCK 5 of 5  |  Probability Density Functions
* source: 02-distributions.qmd line 374  [NEVER EXECUTED - PSPP cannot run it; real SPSS may]
* --------------------------------------------------------------------------.
* Valid SPSS, but shown rather than run: PSPP (the free engine this book uses
* to execute its SPSS tabs) has not implemented GRAPH /LINE.
*
* The standard normal density across a grid of z values from -4 to 4.
INPUT PROGRAM.
LOOP #i = -400 TO 400.
  COMPUTE z = #i / 100.
  COMPUTE density = PDF.NORMAL(z, 0, 1).
  END CASE.
END LOOP.
END FILE.
END INPUT PROGRAM.
EXECUTE.

GRAPH /LINE(SIMPLE) = VALUE(density) BY z.

