* ==========================================================================.
* Statistics in the Wild: The Sports Page Way
* Extracted from 23-sportspage.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 2 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It sets the working
* directory, without which none of the data paths below resolve.
* ==========================================================================.

* --------------------------------------------------------------------------.
* BLOCK 1 of 2  |  A Worked Judgment: The Hot Start Is a Mirage
* source: 23-sportspage.qmd line 52
* --------------------------------------------------------------------------.
* OPS against plate appearances, with a reference line at the league median
* among hitters with 200+ PA.
* GET DATA reads columns POSITIONALLY, so every column in the file has to be
* named - listing only PA and OPS would silently read the first two columns
* (pid and name) under those names instead.
GET DATA /TYPE=TXT /FILE='data/mlb_hitters_2026.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=pid F16.6 name A24 team A24 PA F16.6 AB F16.6 H F16.6 HR F16.6
             BB F16.6 SO F16.6 AVG F16.6 OBP F16.6 SLG F16.6 OPS F16.6.

* First find the median among the qualified hitters.
TEMPORARY.
SELECT IF (PA >= 200).
FREQUENCIES VARIABLES=OPS /STATISTICS=MEDIAN.

GRAPH /SCATTERPLOT(BIVAR) = PA WITH OPS.

* --------------------------------------------------------------------------.
* BLOCK 2 of 2  |  A Worked Judgment: The Hot Start Is a Mirage
* source: 23-sportspage.qmd line 114
* --------------------------------------------------------------------------.
GET DATA /TYPE=TXT /FILE='data/mlb_hitters_2026.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=pid F16.6 name A24 team A24 PA F16.6 AB F16.6 H F16.6 HR F16.6 BB F16.6 SO F16.6 AVG F16.6 OBP F16.6 SLG F16.6 OPS F16.6.
* Spread of OPS at small vs large samples, and the season's best mark.
TEMPORARY.
SELECT IF (PA < 20).
DESCRIPTIVES VARIABLES=OPS /STATISTICS=STDDEV.

TEMPORARY.
SELECT IF (PA >= 200).
DESCRIPTIVES VARIABLES=OPS /STATISTICS=STDDEV.

* The best OPS and the plate appearances behind it.
SORT CASES BY OPS (D).
LIST VARIABLES=OPS PA /CASES=1.

