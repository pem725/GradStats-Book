* ==========================================================================.
* Basic ANOVA
* Extracted from 17-basicANOVA.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 2 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It defines !bookroot,
* which the next line uses to point SPSS at the folder holding data/.
* ==========================================================================.

* Re-anchors the working directory. Harmless to run twice, and it means this
* file works no matter what folder SPSS thinks it is in when you open it.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 2  |  The F Ratio
* source: 17-basicANOVA.qmd line 104
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch17-dose.sps'.
ONEWAY growth BY dose /STATISTICS DESCRIPTIVES /POSTHOC=TUKEY.

* --------------------------------------------------------------------------.
* BLOCK 2 of 2  |  It Really Is the Same as Regression
* source: 17-basicANOVA.qmd line 148
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch17-dose.sps'.
REGRESSION /STATISTICS COEFF R ANOVA /DEPENDENT growth /METHOD=ENTER dose.

