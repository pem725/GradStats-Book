* ==========================================================================.
* Basic ANOVA
* Extracted from 17-basicANOVA.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 2 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It sets the working
* directory, without which none of the data paths below resolve.
* ==========================================================================.

* --------------------------------------------------------------------------.
* BLOCK 1 of 2  |  The F Ratio
* source: 17-basicANOVA.qmd line 104
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch17-dose.sps'.
ONEWAY growth BY dose /STATISTICS DESCRIPTIVES /POSTHOC=TUKEY.

* --------------------------------------------------------------------------.
* BLOCK 2 of 2  |  It Really Is the Same as Regression
* source: 17-basicANOVA.qmd line 148
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch17-dose.sps'.
REGRESSION /STATISTICS COEFF R ANOVA /DEPENDENT growth /METHOD=ENTER dose.

