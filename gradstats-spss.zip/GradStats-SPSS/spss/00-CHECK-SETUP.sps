* ==========================================================================.
* CHECK THE SETUP. Run All after opening this file in SPSS.
*
* The starter filled in the path below. You do not need to edit it.
* If you move this folder later, run the starter again.
* ==========================================================================.

* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.
SHOW DIRECTORY.
INSERT FILE = 'data/sim/ch01-heights.sps'.
DESCRIPTIVES VARIABLES=height /STATISTICS=MEAN.
* The mean height should be about 67.99.

* To send us results, use File > Export in the SPSS output window.
