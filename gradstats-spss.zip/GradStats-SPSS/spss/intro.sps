* ==========================================================================.
* Introduction
* Extracted from intro.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 4 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It sets the working
* directory, without which none of the data paths below resolve.
* ==========================================================================.

* --------------------------------------------------------------------------.
* BLOCK 1 of 4  |  The Helix Model of Learning
* source: intro.qmd line 265  [NEVER EXECUTED - PSPP cannot run it; real SPSS may]
* --------------------------------------------------------------------------.
* Valid SPSS, shown rather than run: PSPP has not implemented the 3-D
* scatterplot. SPSS also has no interactive 3D line plot - the spiral shape
* is visible in a static 3-D scatter, but it cannot be rotated or hovered
* the way the R version can.
INPUT PROGRAM.
LOOP #i = 0 TO 499.
  COMPUTE theta = #i * (6 * 3.14159265 / 499).
  COMPUTE x = COS(theta).
  COMPUTE y = SIN(theta).
  COMPUTE z = theta.
  END CASE.
END LOOP.
END FILE.
END INPUT PROGRAM.
EXECUTE.

GRAPH /SCATTERPLOT(XYZ) = x WITH y WITH z.

* --------------------------------------------------------------------------.
* BLOCK 2 of 4  |  Some Demonstrations
* source: intro.qmd line 369
* --------------------------------------------------------------------------.
* The book's ten people. Height in feet, weight in pounds.
INSERT FILE='data/sim/intro-people.sps'.

GRAPH /HISTOGRAM = height.

* --------------------------------------------------------------------------.
* BLOCK 3 of 4  |  The Rest of the Vocabulary, in One Pass
* source: intro.qmd line 463
* --------------------------------------------------------------------------.
* Everyone picks chocolate, then two samples with different tastes.
* SPSS draws a category by comparing a uniform draw to cumulative
* probabilities - there is no direct equivalent of R's sample(prob = ...).
INPUT PROGRAM.
LOOP #i = 1 TO 1000.
  COMPUTE u = RV.UNIFORM(0, 1).
  DO IF u < .95.
    COMPUTE flavor = 1.
  ELSE IF u < .97.
    COMPUTE flavor = 2.
  ELSE IF u < .98.
    COMPUTE flavor = 3.
  ELSE IF u < .99.
    COMPUTE flavor = 4.
  ELSE.
    COMPUTE flavor = 5.
  END IF.
  END CASE.
END LOOP.
END FILE.
END INPUT PROGRAM.
VALUE LABELS flavor 1 'chocolate' 2 'vanilla' 3 'strawberry'
                    4 'mint chip' 5 'rocky road'.
EXECUTE.

FREQUENCIES VARIABLES=flavor.

* --------------------------------------------------------------------------.
* BLOCK 4 of 4  |  The Rest of the Vocabulary, in One Pass
* source: intro.qmd line 550
* --------------------------------------------------------------------------.
* The mean, median and SD of the ten weights, plus their histogram.
INSERT FILE='data/sim/intro-people.sps'.

DESCRIPTIVES VARIABLES=weight /STATISTICS=MEAN STDDEV.
FREQUENCIES VARIABLES=weight /STATISTICS=MEDIAN /HISTOGRAM.

