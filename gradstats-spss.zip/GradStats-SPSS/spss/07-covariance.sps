* ==========================================================================.
* Covariance and Association
* Extracted from 07-covariance.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 3 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It sets the working
* directory, without which none of the data paths below resolve.
* ==========================================================================.

* --------------------------------------------------------------------------.
* BLOCK 1 of 3  |  From Variance to Covariance
* source: 07-covariance.qmd line 49
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch06-study.sps'.
CORRELATIONS
  /VARIABLES=study grade
  /STATISTICS=XPROD.

* --------------------------------------------------------------------------.
* BLOCK 2 of 3  |  The Units Problem, and the Fix: Correlation
* source: 07-covariance.qmd line 110
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch06-study.sps'.
CORRELATIONS
  /VARIABLES=study grade.

* --------------------------------------------------------------------------.
* BLOCK 3 of 3  |  Variance Is the Fuel
* source: 07-covariance.qmd line 261
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch06-study.sps'.
REGRESSION
  /STATISTICS COEFF R ANOVA
  /DEPENDENT grade
  /METHOD=ENTER study.

