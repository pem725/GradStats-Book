* ==========================================================================.
* Case Study: Building a Measure, Study by Study
* Extracted from 25-casestudy-curiosity.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 2 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 2  |  Study 1 - Explore: How Many Things Are We Even Measuring?
* source: 25-casestudy-curiosity.qmd line 56
* --------------------------------------------------------------------------.
* Twelve items built from three hidden factors, then the scree plot.
INSERT FILE='data/sim/ch28-curiosity.sps'.

FACTOR
  /VARIABLES item1 item2 item3 item4 item5 item6
             item7 item8 item9 item10 item11 item12
  /EXTRACTION PC
  /PRINT INITIAL EXTRACTION
  /PLOT EIGEN.

* --------------------------------------------------------------------------.
* BLOCK 2 of 2  |  Study 1 - Explore: How Many Things Are We Even Measuring?
* source: 25-casestudy-curiosity.qmd line 100  [NO CODE - base SPSS cannot do this; the block says what can]
* --------------------------------------------------------------------------.
* How many factors the data suggest: the count of eigenvalues above 1.
* FACTOR reports this directly - it is the number of components retained
* under the default Kaiser rule in the output above.

