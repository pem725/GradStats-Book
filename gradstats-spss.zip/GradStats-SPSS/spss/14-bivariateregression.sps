* ==========================================================================.
* Simple Regression
* Extracted from 14-bivariateregression.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 3 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It defines !bookroot,
* which the next line uses to point SPSS at the folder holding data/.
* ==========================================================================.

* Re-anchors the working directory. Harmless to run twice, and it means this
* file works no matter what folder SPSS thinks it is in when you open it.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 3  |  The Model
* source: 14-bivariateregression.qmd line 80
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch14-toy.sps'.
REGRESSION
  /STATISTICS COEFF R ANOVA
  /DEPENDENT y
  /METHOD=ENTER x.

* --------------------------------------------------------------------------.
* BLOCK 2 of 3  |  Standardized Coefficients
* source: 14-bivariateregression.qmd line 274
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch14-toy.sps'.
* SPSS prints the standardized Beta in the coefficients table by default,
* so the ordinary regression yields the standardized slope with no extra steps.
REGRESSION
  /STATISTICS COEFF R ANOVA
  /DEPENDENT y
  /METHOD=ENTER x.

* --------------------------------------------------------------------------.
* BLOCK 3 of 3  |  A Real Example
* source: 14-bivariateregression.qmd line 337
* --------------------------------------------------------------------------.
GET DATA /TYPE=TXT /FILE='data/gpa.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=CollegeGPA F16.6 HSGPA F16.6 SATtotal F16.6 QLOR F16.6.
REGRESSION
  /STATISTICS COEFF R ANOVA
  /DEPENDENT CollegeGPA
  /METHOD=ENTER HSGPA.

