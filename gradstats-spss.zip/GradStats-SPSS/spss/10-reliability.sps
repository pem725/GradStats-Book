* ==========================================================================.
* Reliability (not Validity) of Data
* Extracted from 10-reliability.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 4 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It defines !bookroot,
* which the next line uses to point SPSS at the folder holding data/.
* ==========================================================================.

* Re-anchors the working directory. Harmless to run twice, and it means this
* file works no matter what folder SPSS thinks it is in when you open it.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 4  |  Reliability Is a Ratio of Variances
* source: 10-reliability.qmd line 65
* --------------------------------------------------------------------------.
* The book's own true/error/observed scores. Reliability is the true-score
* share of the observed variance, read off the two variances below.
INSERT FILE='data/sim/ch09-ctt.sps'.

DESCRIPTIVES VARIABLES=truth observed /STATISTICS=VARIANCE.

* --------------------------------------------------------------------------.
* BLOCK 2 of 4  |  Cronbach's Alpha, By Hand
* source: 10-reliability.qmd line 120
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch09-items-tau.sps'.
* Cronbach's alpha for six items sharing a common factor.
* NOTE (for Jeff): this is the section reserved for your SPSS review -
* RELIABILITY is the workhorse, and its output reports raw alpha plus the
* alpha-if-item-deleted table the R tab builds by hand further down.
RELIABILITY
  /VARIABLES=item1 item2 item3 item4 item5 item6
  /MODEL=ALPHA
  /SUMMARY=TOTAL.

* --------------------------------------------------------------------------.
* BLOCK 3 of 4  |  Measurement Models: How Equal Are Your Items?
* source: 10-reliability.qmd line 190
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch09-items-congeneric.sps'.
* Alpha assumes tau-equivalence; with unequal loadings it UNDERSTATES
* reliability, and McDonald's omega is the right coefficient.
* RELIABILITY gives alpha directly.
RELIABILITY
  /VARIABLES=item1 item2 item3 item4 item5
  /MODEL=ALPHA.

* Omega needs the factor loadings. Base SPSS has no omega keyword, so you
* extract a one-factor solution and compute omega from its output:
*   omega = (SUM lambda)^2 / ((SUM lambda)^2 + SUM psi)
* In SPSS the extraction line reads /EXTRACTION=ML, matching the R tab.
* PSPP offers PAF, PC and PA1 but not ML, so principal axis factoring runs
* here; on this data the loadings agree to the two decimals we print.
FACTOR
  /VARIABLES=item1 item2 item3 item4 item5
  /EXTRACTION=PAF
  /CRITERIA=FACTORS(1)
  /PRINT=INITIAL EXTRACTION.

* --------------------------------------------------------------------------.
* BLOCK 4 of 4  |  Why You Should Care: Attenuation
* source: 10-reliability.qmd line 276
* --------------------------------------------------------------------------.
* Attenuation: unreliable sensors shrink the correlation you can observe.
INPUT PROGRAM.
LOOP #i = 1 TO 1000.
  COMPUTE Tx = RV.NORMAL(0, 1).
  COMPUTE Ty = 0.6 * Tx + RV.NORMAL(0, 0.8).
  COMPUTE Ox = Tx + RV.NORMAL(0, 1).
  COMPUTE Oy = Ty + RV.NORMAL(0, 1).
  END CASE.
END LOOP.
END FILE.
END INPUT PROGRAM.
EXECUTE.

* The true correlation, then the one a noisy sensor actually reports.
CORRELATIONS /VARIABLES=Tx Ty.
CORRELATIONS /VARIABLES=Ox Oy.

