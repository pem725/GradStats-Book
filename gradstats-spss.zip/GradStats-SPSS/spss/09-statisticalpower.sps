* ==========================================================================.
* Statistical Power: How to Find Things That May Not Be There
* Extracted from 09-statisticalpower.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 4 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 4  |  Seeing Power in R
* source: 09-statisticalpower.qmd line 86  [NEVER EXECUTED - PSPP cannot run it; real SPSS may]
* --------------------------------------------------------------------------.
* IBM SPSS Statistics 27+ Base Edition: power for two independent groups.
* N is per group; MEAN is the assumed difference and SD the common SD.
* PSPP cannot run POWER, so these IBM commands are shown for SPSS users.
POWER MEANS INDEPENDENT
  /PARAMETERS N=30 30 SD=1 MEAN=0.5 SIGNIFICANCE=0.01.
POWER MEANS INDEPENDENT
  /PARAMETERS N=30 30 SD=1 MEAN=0.5 SIGNIFICANCE=0.05.
POWER MEANS INDEPENDENT
  /PARAMETERS N=30 30 SD=1 MEAN=0.5 SIGNIFICANCE=0.10.

* --------------------------------------------------------------------------.
* BLOCK 2 of 4  |  Seeing Power in R
* source: 09-statisticalpower.qmd line 136  [NEVER EXECUTED - PSPP cannot run it; real SPSS may]
* --------------------------------------------------------------------------.
* IBM SPSS Statistics 27+ Base Edition; PSPP cannot run POWER.
* Change N while holding the assumed mean difference, SD, and alpha fixed.
POWER MEANS INDEPENDENT
  /PARAMETERS N=20 20 SD=1 MEAN=0.5 SIGNIFICANCE=0.05.
POWER MEANS INDEPENDENT
  /PARAMETERS N=50 50 SD=1 MEAN=0.5 SIGNIFICANCE=0.05.
POWER MEANS INDEPENDENT
  /PARAMETERS N=100 100 SD=1 MEAN=0.5 SIGNIFICANCE=0.05.

* --------------------------------------------------------------------------.
* BLOCK 3 of 4  |  Planning a Study: Solve for n
* source: 09-statisticalpower.qmd line 186  [NEVER EXECUTED - PSPP cannot run it; real SPSS may]
* --------------------------------------------------------------------------.
* IBM SPSS Statistics 27+ Base Edition; PSPP cannot run POWER.
* Ask for the group size that reaches 80% power with equal allocation.
POWER MEANS INDEPENDENT
  /PARAMETERS POWER=0.80 NRATIO=1 SD=1 MEAN=0.5 SIGNIFICANCE=0.05.

* --------------------------------------------------------------------------.
* BLOCK 4 of 4  |  Power Is Really Just Simulation
* source: 09-statisticalpower.qmd line 239
* --------------------------------------------------------------------------.
* The simulation approach DOES work in base SPSS, because it needs only
* data generation and a t test - no power module required. Generate two
* groups with a real difference, test, repeat, and count the hits.
INPUT PROGRAM.
LOOP #rep = 1 TO 2000.
  LOOP #i = 1 TO 64.
    COMPUTE rep = #rep.
    COMPUTE grp = 1.
    COMPUTE y = RV.NORMAL(0, 1).
    END CASE.
    COMPUTE grp = 2.
    COMPUTE y = RV.NORMAL(0.5, 1).
    END CASE.
  END LOOP.
END LOOP.
END FILE.
END INPUT PROGRAM.
EXECUTE.

* Run the t test within each replication, then the fraction with p < .05
* is the simulated power.
SORT CASES BY rep.
SPLIT FILE BY rep.
T-TEST GROUPS=grp(1 2) /VARIABLES=y.
SPLIT FILE OFF.

