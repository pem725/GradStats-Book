* ==========================================================================.
* Statistical Power: How to Find Things That May Not Be There
* Extracted from 09-statisticalpower.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 4 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It defines !bookroot,
* which the next line uses to point SPSS at the folder holding data/.
* ==========================================================================.

* Re-anchors the working directory. Harmless to run twice, and it means this
* file works no matter what folder SPSS thinks it is in when you open it.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 4  |  Seeing Power in R
* source: 09-statisticalpower.qmd line 86  [NO CODE - base SPSS cannot do this; the block says what can]
* --------------------------------------------------------------------------.
* Base SPSS has no power analysis. Power and sample-size planning live in
* the separate, separately licensed SamplePower module (Analyze > Power
* Analysis in recent versions), or in an external tool such as G*Power.
*
* * The question here - how power moves as alpha goes .01 -> .05 -> .10 -
* is answered in the R, Julia, and Python tabs.

* --------------------------------------------------------------------------.
* BLOCK 2 of 4  |  Seeing Power in R
* source: 09-statisticalpower.qmd line 132  [NO CODE - base SPSS cannot do this; the block says what can]
* --------------------------------------------------------------------------.
* Base SPSS has no power analysis. Power and sample-size planning live in
* the separate, separately licensed SamplePower module (Analyze > Power
* Analysis in recent versions), or in an external tool such as G*Power.
*
* * The question here - how power grows with n = 20, 50, 100 per group -
* is answered in the R, Julia, and Python tabs.

* --------------------------------------------------------------------------.
* BLOCK 3 of 4  |  Planning a Study: Solve for n
* source: 09-statisticalpower.qmd line 179  [NO CODE - base SPSS cannot do this; the block says what can]
* --------------------------------------------------------------------------.
* Base SPSS has no power analysis. Power and sample-size planning live in
* the separate, separately licensed SamplePower module (Analyze > Power
* Analysis in recent versions), or in an external tool such as G*Power.
*
* * The question here - the n needed for 80% power at d = 0.5 -
* is answered in the R, Julia, and Python tabs.

* --------------------------------------------------------------------------.
* BLOCK 4 of 4  |  Power Is Really Just Simulation
* source: 09-statisticalpower.qmd line 233
* --------------------------------------------------------------------------.
* The simulation approach DOES work in base SPSS, because it needs only
* data generation and a t test - no power module required. Generate two
* groups with a real difference, test, repeat, and count the hits.
INPUT PROGRAM.
LOOP #rep = 1 TO 2000.
  LOOP #i = 1 TO 64.
    COMPUTE rep = #rep.
    COMPUTE grp = 1.
    COMPUTE y = RV.NORMAL(0, 1).
    END CASE.
    COMPUTE grp = 2.
    COMPUTE y = RV.NORMAL(0.5, 1).
    END CASE.
  END LOOP.
END LOOP.
END FILE.
END INPUT PROGRAM.
EXECUTE.

* Run the t test within each replication, then the fraction with p < .05
* is the simulated power.
SORT CASES BY rep.
SPLIT FILE BY rep.
T-TEST GROUPS=grp(1 2) /VARIABLES=y.
SPLIT FILE OFF.

