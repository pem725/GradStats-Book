* ==========================================================================.
* Outcomes with a Floor and a Ceiling
* Extracted from 34-bounded.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 6 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 6  |  The Data
* source: 34-bounded.qmd line 46
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch34-wellbeing.sps'.

* How many people sit exactly on the floor of the scale?
COMPUTE at_floor = (wellbeing = 0).
EXECUTE.
MEANS TABLES=wellbeing at_floor BY group
  /CELLS=COUNT MEAN MIN MAX.

* --------------------------------------------------------------------------.
* BLOCK 2 of 6  |  What Ordinary Regression Says
* source: 34-bounded.qmd line 98
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch34-wellbeing.sps'.

* Least squares on a bounded outcome. Watch the residual spread by group,
* and note that nothing in this model knows the scale stops at 0 and 100.
COMPUTE treated = (group = 'treated').
EXECUTE.

REGRESSION
  /STATISTICS=COEFF R ANOVA
  /DEPENDENT wellbeing
  /METHOD=ENTER treated
  /SAVE PRED RESID.

* --------------------------------------------------------------------------.
* BLOCK 3 of 6  |  Binary: Logistic Regression
* source: 34-bounded.qmd line 195
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch34-wellbeing.sps'.

* Binary outcome: did the person reach the halfway mark of the scale?
COMPUTE reached50 = (wellbeing >= 50).
COMPUTE treated   = (group = 'treated').
EXECUTE.

LOGISTIC REGRESSION reached50 WITH treated.

* --------------------------------------------------------------------------.
* BLOCK 4 of 6  |  Beta Regression, By Hand
* source: 34-bounded.qmd line 309  [NO CODE - base SPSS cannot do this; the block says what can]
* --------------------------------------------------------------------------.
* Base SPSS has no beta regression. GENLIN offers binomial, Poisson, gamma
* and several other families, but not beta, and there is no user-written
* equivalent that ships with it.
*
* Where it does exist:
*   R      betareg::betareg(y ~ x)
*   Stata  betareg y x          (built in)
*   Python statsmodels.othermod.betareg.BetaModel
*
* The nearest honest thing base SPSS can do is the logistic model above, on
* a binary version of the outcome, which answers a different question and
* discards the difference between a score of 51 and a score of 99.

* --------------------------------------------------------------------------.
* BLOCK 5 of 6  |  Beta Regression, By Hand
* source: 34-bounded.qmd line 379  [NO CODE - base SPSS cannot do this; the block says what can]
* --------------------------------------------------------------------------.
* Still no beta family in base SPSS - see the note in the tab above.
* The R, Julia, and Python tabs fit the model; this one cannot.

* --------------------------------------------------------------------------.
* BLOCK 6 of 6  |  Reading the Answer
* source: 34-bounded.qmd line 423  [NO CODE - base SPSS cannot do this; the block says what can]
* --------------------------------------------------------------------------.
* No beta family in base SPSS; see above.

