* ==========================================================================.
* More Item Response Theory, and Generalizability
* Extracted from 30-irt.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 1 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It sets the working
* directory, without which none of the data paths below resolve.
* ==========================================================================.

* --------------------------------------------------------------------------.
* BLOCK 1 of 1  |  Generalizability: Reliability, Grown Up
* source: 30-irt.qmd line 95
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch23-gtheory.sps'.
* Data assumed present as the active dataset with columns score, p (person), i (item).
* VARCOMP returns the person, item, and residual variance components directly,
* no hand EMS math from mean squares.
VARCOMP score BY p i
  /RANDOM = p i
  /METHOD = REML.

