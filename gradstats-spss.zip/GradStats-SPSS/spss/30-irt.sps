* ==========================================================================.
* More Item Response Theory, and Generalizability
* Extracted from 30-irt.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 1 block(s). Run the file top to bottom, or one block at a time.
*
* RUN 00-START-HERE.sps FIRST, once per SPSS session. It defines !bookroot,
* which the next line uses to point SPSS at the folder holding data/.
* ==========================================================================.

* Re-anchors the working directory. Harmless to run twice, and it means this
* file works no matter what folder SPSS thinks it is in when you open it.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 1  |  Generalizability: Reliability, Grown Up
* source: 30-irt.qmd line 95
* --------------------------------------------------------------------------.
INSERT FILE='data/sim/ch23-gtheory.sps'.
* Data assumed present as the active dataset with columns score, p (person), i (item).
* VARCOMP returns the person, item, and residual variance components directly,
* no hand EMS math from mean squares.
VARCOMP score BY p i
  /RANDOM = p i
  /METHOD = REML.

