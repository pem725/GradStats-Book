* ==========================================================================.
* Displaying Data: Graphics
* Extracted from 21-graphics.qmd by setup/make_spss_kit.R. Do not hand-edit -
* fix the chapter and rebuild, or the book and this kit drift apart.
*
* 7 block(s). Run the file top to bottom, or one block at a time.
*
* Run START-WINDOWS.cmd or START-MAC.command after unzipping the kit.
* That starter fills in the next line using this folder's actual location.
* ==========================================================================.

* This absolute path is prepared automatically. Run this chapter on its own.
* BOOKROOT-AUTO-CONFIGURED.
CD !bookroot.

* --------------------------------------------------------------------------.
* BLOCK 1 of 7  |  Match the Geometry to the Question
* source: 21-graphics.qmd line 43
* --------------------------------------------------------------------------.
* A trend over time wants a line.
GET DATA /TYPE=TXT /FILE='data/mlb_league_by_year.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=year F16.6 OPS F16.6 K_PA F16.6 BB_PA F16.6 HR_PA F16.6 AVG F16.6 ERA F16.6 K_9 F16.6 BB_9 F16.6 HR_9 F16.6.

GRAPH /LINE(SIMPLE) = VALUE(K_9) BY year.

* --------------------------------------------------------------------------.
* BLOCK 2 of 7  |  Don't Lie With the Axis
* source: 21-graphics.qmd line 93
* --------------------------------------------------------------------------.
GET DATA /TYPE=TXT /FILE='data/mlb_league_by_year.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=year F16.6 OPS F16.6 K_PA F16.6 BB_PA F16.6 HR_PA F16.6 AVG F16.6 ERA F16.6 K_9 F16.6 BB_9 F16.6 HR_9 F16.6.
* Dishonest axis: zoom the y scale tight and a 15-point drift looks
* like a cliff. In the chart editor you would set the y-axis minimum to
* .242 and maximum to .258; in syntax, GGRAPH carries the scale range.
GGRAPH
  /GRAPHDATASET NAME="g" VARIABLES=year AVG
  /GRAPHSPEC SOURCE=INLINE
  /FRAME INNER=YES.
BEGIN GPL
  SOURCE: s=userSource(id("g"))
  DATA: year=col(source(s), name("year"))
  DATA: AVG=col(source(s), name("AVG"))
  SCALE: linear(dim(2), min(0.242), max(0.258))
  GUIDE: text.title(label("Hitting is DEAD"))
  ELEMENT: line(position(year*AVG))
END GPL.

* --------------------------------------------------------------------------.
* BLOCK 3 of 7  |  Don't Lie With the Axis
* source: 21-graphics.qmd line 151
* --------------------------------------------------------------------------.
GET DATA /TYPE=TXT /FILE='data/mlb_league_by_year.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=year F16.6 OPS F16.6 K_PA F16.6 BB_PA F16.6 HR_PA F16.6 AVG F16.6 ERA F16.6 K_9 F16.6 BB_9 F16.6 HR_9 F16.6.
* Honest axis: from a meaningful zero, the same drift is a gentle slope.
GGRAPH
  /GRAPHDATASET NAME="g" VARIABLES=year AVG
  /GRAPHSPEC SOURCE=INLINE
  /FRAME INNER=YES.
BEGIN GPL
  SOURCE: s=userSource(id("g"))
  DATA: year=col(source(s), name("year"))
  DATA: AVG=col(source(s), name("AVG"))
  SCALE: linear(dim(2), min(0), max(0.3))
  GUIDE: text.title(label("Hitting drifted down a bit"))
  ELEMENT: line(position(year*AVG))
END GPL.

* --------------------------------------------------------------------------.
* BLOCK 4 of 7  |  Small Multiples Beat Overloaded Dual-Axis Charts
* source: 21-graphics.qmd line 220  [NEVER EXECUTED - PSPP cannot run it; real SPSS may]
* --------------------------------------------------------------------------.
* Valid SPSS, shown rather than run: PSPP has implemented neither
* VARSTOCASES (which stacks the three rate columns into long form) nor
* GGRAPH's PANEL clause, which is how SPSS draws small multiples.
GET DATA /TYPE=TXT /FILE='data/mlb_league_by_year.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=year F16.6 K_PA F16.6 BB_PA F16.6 HR_PA F16.6.

VARSTOCASES /MAKE rate FROM K_PA BB_PA HR_PA /INDEX=kind.

GGRAPH /GRAPHDATASET NAME="g" VARIABLES=year rate kind
  /GRAPHSPEC SOURCE=INLINE.
BEGIN GPL
  SOURCE: s=userSource(id("g"))
  DATA: year=col(source(s), name("year"))
  DATA: rate=col(source(s), name("rate"))
  DATA: kind=col(source(s), name("kind"), unit.category())
  ELEMENT: line(position(year*rate*kind))
END GPL.

* --------------------------------------------------------------------------.
* BLOCK 5 of 7  |  Rank, Don't Pie
* source: 21-graphics.qmd line 290
* --------------------------------------------------------------------------.
* Rank, don't pie: a sorted horizontal bar chart of bust rate by team.
GET DATA /TYPE=TXT /FILE='data/nfl_draft_by_team.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=team A24 n_picks F16.6 n_judged F16.6 n_hof F16.6 n_bust_a F16.6 n_bust_b F16.6 n_bust_c F16.6 n_triple_bust F16.6 n_clean_hit F16.6 rate_bust_a F16.6 rate_bust_b F16.6 rate_bust_c F16.6 rate_triple_bust F16.6 rate_clean_hit F16.6 hof_per_pick F16.6.

SORT CASES BY rate_bust_a (A).

* MEAN() rather than VALUE() here: each team has exactly one row, so the
* two are identical, and MEAN() is accepted by every SPSS-family engine.
GRAPH /BAR(SIMPLE) = MEAN(rate_bust_a) BY team.
* In the chart editor, transpose to horizontal so the team labels stay
* readable - the equivalent of coord_flip().

* --------------------------------------------------------------------------.
* BLOCK 6 of 7  |  Show the Distribution, Not Just the Mean
* source: 21-graphics.qmd line 355
* --------------------------------------------------------------------------.
* Show the distribution, not just the mean.
GET DATA /TYPE=TXT /FILE='data/mlb_hitters_2026.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=pid F16.6 name A24 team A24 PA F16.6 AB F16.6 H F16.6 HR F16.6 BB F16.6 SO F16.6 AVG F16.6 OBP F16.6 SLG F16.6 OPS F16.6.
SELECT IF (PA >= 50).
EXECUTE.

FREQUENCIES VARIABLES=OPS /STATISTICS=MEDIAN /HISTOGRAM.

* --------------------------------------------------------------------------.
* BLOCK 7 of 7  |  Show the Distribution, Not Just the Mean
* source: 21-graphics.qmd line 404
* --------------------------------------------------------------------------.
GET DATA /TYPE=TXT /FILE='data/mlb_hitters_2026.csv'
  /DELIMITERS=',' /QUALIFIER='"' /FIRSTCASE=2
  /VARIABLES=pid F16.6 name A24 team A24 PA F16.6 AB F16.6 H F16.6 HR F16.6 BB F16.6 SO F16.6 AVG F16.6 OBP F16.6 SLG F16.6 OPS F16.6.
* Transparency tames overplotting. SPSS sets marker transparency in the
* chart editor, or through GGRAPH's transparency() aesthetic.
GGRAPH
  /GRAPHDATASET NAME="g" VARIABLES=OBP SLG
  /GRAPHSPEC SOURCE=INLINE.
BEGIN GPL
  SOURCE: s=userSource(id("g"))
  DATA: OBP=col(source(s), name("OBP"))
  DATA: SLG=col(source(s), name("SLG"))
  GUIDE: axis(dim(1), label("On-base percentage"))
  GUIDE: axis(dim(2), label("Slugging percentage"))
  ELEMENT: point(position(OBP*SLG), transparency.exterior(transparency."0.65"))
END GPL.

